import React, { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { motion } from "framer-motion";
import { FaStar, FaUsers, FaChartLine, FaPuzzlePiece } from "react-icons/fa";
import AOS from "aos";
import "aos/dist/aos.css";
import "./FeatureCards.css";

const features = [
    {
        icon: <FaStar className="icon text-danger" />,
        title: "Comprehensive Inventory Management",
        description:
            "Efficiently track, manage, and optimize your jewellery inventory with advanced features tailored for the jewellery industry.",
    },
    {
        icon: <FaUsers className="icon text-primary" />,
        title: "Customer-Centric Approach",
        description:
            "Deliver exceptional customer experiences through personalized services and tailored recommendations, fostering long-term relationships.",
    },
    {
        icon: <FaChartLine className="icon text-success" />,
        title: "Real-Time Analytics",
        description:
            "Gain valuable insights into sales trends, customer preferences, and inventory performance, empowering data-driven decision-making for business growth.",
    },
    {
        icon: <FaPuzzlePiece className="icon text-warning" />,
        title: "Seamless Integration",
        description:
            "Integrate seamlessly with existing systems and platforms, ensuring a smooth transition and maximizing operational efficiency.",
    },
];

const FeatureCards = () => {
    const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);

    useEffect(() => {
        AOS.init({ duration: 1000 });

        const handleResize = () => {
            setIsMobile(window.innerWidth <= 768);
        };

        window.addEventListener("resize", handleResize);
        return () => window.removeEventListener("resize", handleResize);
    }, []);

    return (
        <div className="feature-container">
            <h6 className="sub-heading">Why Aurumm - AU Pay?</h6>
            <h2 className="main-heading">Euismod Scelerisque Pretiumdui</h2>
            <div className="feature-grid">
                {features.map((feature, index) => (
                    <motion.div
                        key={index}
                        className="feature-card"
                        initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.5 }}
                        whileHover={{ scale: 1.1 }}
                        data-aos={isMobile ? "fade-up" : ""}
                    >
                        <div className="icon-container">{feature.icon}</div>
                        <h3 className="feature-title">{feature.title}</h3>
                        <p className="feature-description">{feature.description}</p>
                    </motion.div>
                ))}
            </div>
        </div>
    );
};

export default FeatureCards;
